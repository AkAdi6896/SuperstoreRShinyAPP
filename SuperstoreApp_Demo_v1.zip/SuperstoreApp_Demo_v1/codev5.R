library(shiny)
library(shinydashboard)
library(shinyjs)
library(plotly)
library(rgdal)
library(rgeos)
library(maptools)
library(raster)
library(deldir)
library(leaflet)
library(DT)
library(lubridate)
library(dplyr)
library(stringr)
library(shinyalert)
library(shinycssloaders)

directory_path <- "C:/Users/91877/Desktop/My_Projects/SuperstoreAPP_Demo/SuperstoreApp_Demo_v1"
setwd(directory_path)

header <- dashboardHeader(title = tags$a(tags$img(src = 'customer_01.jpg', height = '40', width = '100', title = 'Superstore')), titleWidth = 230
                          #tags$li(class = "dropdown", actionButton("home",icon("home"),style='height:50px'))
                          , tags$li(class = "dropdown", uiOutput("home_2")),
                          tags$li(class = "dropdown", uiOutput("logout")))

sidebar <- dashboardSidebar(uiOutput("sidebarpanel"))

body <- dashboardBody(fluidPage(theme = "style.css",
                                
                                tags$head(includeCSS(paste0(directory_path, "/WWW/style.css"))),
                                useShinyalert(),
                                tags$script(HTML('
                   $(document).ready(function() {
                   $("header").find("nav").append(\'<span class="myClass"> Superstore Analysis Project </span>\');
                   })
                   ')), uiOutput("body"))
)

login_details <- data.frame(user = c("abc"),
                            pswd = c("def"))
login <- 
  
  tagList(
    div(
      id = "login",
      tags$hr(),
      wellPanel(
        fluidRow(align="center", offset = 2,
                 htmlOutput("login_head"),
                 tags$style(type="text/css", "#string { height: 50px; width: 100%; text-align:center; font-size: 30px; display: block;}")
                 ),
        
        textInput("userName", "Username"),
        passwordInput("passwd", "Password"),
        br(),
        actionButton("Login", "Log in"),
        br()
      )
      
    ),
    div(
      id = "bblogo",
      tags$img(src = "Business-Brio-black.png", width = "60px", height = "30px"),
      "Designed and Developed by Aditya Chourasia copyright (c) 2020"
    )
  )



#ui
ui <-dashboardPage(title = "RA Intelligence and Forecasting System", header, sidebar, body)

shape1 <- readOGR(paste0(directory_path, "/tl_2017_us_state/tl_2017_us_state.shp"), layer="tl_2017_us_state")

## Our old code is downwards

#Defining the server
server <- function(input,output, session){
  
  login.page = paste(
    isolate(session$clientData$url_protocol),
    "//",
    isolate(session$clientData$url_hostname),
    ":",
    isolate(session$clientData$url_port),
    sep = ""
  )
  # 
  USER <- reactiveValues(Logged = F)   # Initially logged off
  
  observe({
    if (USER$Logged == FALSE) {
      if (!is.null(input$Login)) {
        if (input$Login > 0) {
          Username <- isolate(input$userName)
          Password <- isolate(input$passwd)
          Id.username <- which(login_details$user %in% Username)
          Id.password <- which(login_details$pswd %in% Password)
          if (length(Id.username) > 0 & length(Id.password) > 0){
            if (Id.username == Id.password) {
              USER$Logged <- TRUE
            }
          }else if(length(Id.username) == 0 | length(Id.password) == 0){
            # showModal(modalDialog(
            #   title = "Login Unsuccessful!",
            #   "Please enter correct credentials",
            #   easyClose = TRUE,
            #   footer = NULL
            # ))
            shinyalert("Unsuccessful Login!", "Please enter correct credentials.", type = "error")
            
            # print("Login Unsuccessful. Please try again.")
          }
        }
      }
    }
  })
  
  output$login_head <- renderUI({
    HTML(paste('<b>','<p style="color:blue">', 'LOGIN','</p>', '</b>'))
  })
  
  output$logout<-renderUI({
    if (USER$Logged == TRUE){
      actionButton("logout2", 
                   label = "Log Out", 
                   icon = icon("sign-out"), 
                   style='height:50px', 
                   onclick = paste0("location.href='",login.page,"';")
      )
    }
  })
  
  output$home_2 <- renderUI({
    if (USER$Logged == TRUE){
      actionButton("home", label = "Home", icon = icon("home"), style='height:50px')
    }
  })
  
  output$body <- renderUI({
    if (USER$Logged == TRUE) {
      tabItems(
        
        tabItem(tabName = "Data_Analysis",
                tabsetPanel(type = "tabs",selected = "Data Upload",id="intabset4",
                            tabPanel("Data Upload",
                                     useShinyjs(),
                                     fluidPage(
                                       useShinyalert(),
                                       
                                       tags$head(includeCSS(paste0(directory_path, "/WWW/style.css"))),
                                       tags$br(),
                                       fluidRow(column(4, fileInput('file1', 'Upload the Superstore data xls file',
                                                                    accept = c(".xls")))),
                                       tags$br(),
                                       fluidRow(column(12,DT::dataTableOutput("responses")  %>% withSpinner(color="#0dc5c1"))),
                                       tags$br(),
                                       tags$br(),
                                       fluidRow(column(2,actionButton("button_continue_analysis", "Continue Analysis"))),
                                       tags$br(),
                                       fluidRow(div(
                                         id = "bblogo",
                                         "Designed and Developed by Aditya Chourasia copyright (c) 2020"
                                       ))
                                       
                                     )
                            ),
                            tabPanel("Analysis",
                                     fluidPage(
                                       tags$head(includeCSS(paste0(directory_path, "/WWW/style.css"))),
                                       tags$br(),
                                       fluidRow(column(12, htmlOutput("analysis_data_text"))),
                                       fluidRow(column(2, uiOutput("year_1"))),
                                       fluidRow(column(12, h3(uiOutput("trend_plot_head")))),
                                       fluidRow(column(10, uiOutput("trend_plot")  %>% withSpinner(color="#0dc5c1")),
                                                column(2, uiOutput("trend_data_download"))),
                                       fluidRow(column(12, uiOutput("trend_plot_text"))),
                                       tags$br(),
                                       tags$br(),
                                       # plotlyOutput("trend_plot"),
                                       fluidRow(column(12, h3(uiOutput("reg_sale_barplot_head")))),
                                       fluidRow(column(10, uiOutput("reg_sale_barplot")  %>% withSpinner(color="#0dc5c1")),
                                                column(2, uiOutput("bar_data_download"))),
                                       fluidRow(column(12, uiOutput("reg_sale_barplot_text"))),
                                       tags$br(),
                                       tags$br(),
                                       fluidRow(column(12, h3(uiOutput("state_wise_sales_map_head")))),
                                       fluidRow(column(10, uiOutput("state_wise_sales_map")  %>% withSpinner(color="#0dc5c1")),
                                                column(2, uiOutput("map_data_download"))),
                                       fluidRow(column(12, uiOutput("state_wise_sales_map_text"))),
                                       tags$br(),
                                       tags$br(),
                                       fluidRow(column(2,uiOutput("button_start_analysis"))),
                                       tags$br(),
                                       fluidRow(div(
                                         id = "bblogo",
                                         "Designed and Developed by Aditya Chourasia copyright (c) 2020"
                                       ))
                                     )
                            ),
                            tabPanel("Cluster Analysis",
                                     fluidPage(
                                       tags$head(includeCSS(paste0(directory_path, "/WWW/style.css"))),
                                       useShinyjs(),
                                       tags$br(),
                                       fluidRow(column(12, uiOutput("ca_data_text"))),
                                       fluidRow(column(3, uiOutput("dep")),
                                                column(2, uiOutput("year")),
                                                column(2, uiOutput("kval")),
                                                column(2, uiOutput("niter")),
                                                column(2, uiOutput("seed"))),
                                       tags$br(),
                                       fluidRow(column(12, h3(uiOutput("cluster_head")))),
                                       fluidRow(column(7, uiOutput("ClusterSummary_tab")  %>% withSpinner(color="#0dc5c1"))),
                                       tags$br(),
                                       fluidRow(div(
                                         id = "bblogo",
                                         "Designed and Developed by Aditya Chourasia copyright (c) 2020"
                                       ))
                                     )
                            )
                )
        )
        
      ) # tabitems
    }
    else {
      login
    }
  })  # body ends here
  
  observeEvent(input$Login, {
    if (USER$Logged == TRUE){
      output$sidebarpanel <- renderUI({
        
        sidebarMenu(id="tabs", selected = "Data_Analysis",
                    menuItem("Data Analysis", tabName = "Data_Analysis", icon = icon("th"))
        )
        
      })
      updateTabItems(session, "tabs", "Data_Analysis")
      
    }
  })
  
  observeEvent(input$home, {
    if (USER$Logged == TRUE) {
      output$sidebarpanel <- renderUI({
        
        sidebarMenu(id="tabs", selected = "Data_Analysis",
                    menuItem("Data Analysis", tabName = "Data_Analysis", icon = icon("th"))
        )
        
      })
    }
    updateTabItems(session, "tabs", "Data_Analysis")
    updateTabsetPanel(session, "intabset4", selected = "Data Upload")
  })
  
  
  output$responses <- DT::renderDataTable({
    input$submit_1
    if (!is.null(input$file1)){
      
      if(str_sub(input$file1$name, -3) != "xls"){
        # showNotification(paste0("Please upload the xls file only"), duration = 10, type = "error")
        # showModal(modalDialog(
        #   title = "File Format Error",
        #   "Please upload the xls file.",
        #   easyClose = TRUE,
        #   footer = NULL
        # ))
        
        shinyalert("File Format Error!", "Please upload the xls file.", type = "error")
        
        # input$file1 <- NULL
      }else{
        # print(paste0("Line 103: ", input$file1))
        # if(input$file1$name)
        
        data <- readxl::read_xls(input$file1$datapath)
        # print(colnames(data))
        datatable(data, 
                  options = list(
                    dom = 't',
                    scroller = TRUE,
                    scrollX = TRUE, 
                    "pageLength" = 100),
                  rownames = FALSE
        )
      }
      # 'data.frame':	1 obs. of  4 variables:
      #   $ name    : chr "Sample - Superstore_csv.csv"
    }
  })
  
  
  # actionButton("button_start_analysis","Start Analysis")
  
  output$button_start_analysis <- renderUI({
    if(is.null(input$file1)){
      # print("161")
      return()
    }else if(!is.null(input$file1) & str_sub(input$file1$name, -3) == "xls"){
      actionButton("dyn_button_start_analysis","Start Analysis")
    }else if(!is.null(input$file1) & str_sub(input$file1$name, -3) != "xls"){
      return()
    }
  })
  
  
  observe({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        shinyjs::enable("button_continue_analysis")
        shinyjs::enable("button_start_analysis")
      }else{
        shinyjs::disable("button_continue_analysis")
        shinyjs::disable("button_start_analysis")
      }
    }else{
      shinyjs::disable("button_continue_analysis")
      shinyjs::disable("button_start_analysis")
    }
  })
  
  
  
  
  
  
  observeEvent(input$button_continue_analysis, {
    updateTabItems(session, "tabs", "Data_Analysis")
    updateTabsetPanel(session, "intabset4",
                      selected = "Analysis"
    )
  })
  
  observeEvent(input$dyn_button_start_analysis, {
    updateTabItems(session, "tabs", "Data_Analysis")
    updateTabsetPanel(session, "intabset4",
                      selected = "Cluster Analysis"
    )
  })
  
  
  output$analysis_data_text <- renderUI({
    
    if(is.null(input$file1)){
      HTML(paste('<b>','<p style="color:red">', 'Please upload the Superstore data in the ','"Data Upload"', ' tab to see the plots.','</p>', '</b>'))
    }else if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) != "xls"){
        HTML(paste('<b>','<p style="color:red">', 'Please upload the proper format of Superstore data in the ','"Data Upload"', ' tab to see the plots.','</p>', '</b>'))
        # HTML(paste("<b>","Please upload the proper format of Superstore data in the ","'Data Upload'", " tab to see the plots.","</b>"))
      }else{
        return()
      }
    }
    
  })
  
  
  
  output$ca_data_text <- renderUI({
    
    if(is.null(input$file1)){
      HTML(paste('<b>','<p style="color:red">', 'Please upload the Superstore data in the ','"Data Upload"', ' tab to see the cluster summary.','</p>', '</b>'))
    }else if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) != "xls"){
        HTML(paste('<b>','<p style="color:red">', 'Please upload the proper format of Superstore data in the ','"Data Upload"', ' tab to see the cluster summary.','</p>', '</b>'))
        # HTML(paste("<b>","Please upload the proper format of Superstore data in the ","'Data Upload'", " tab to see the plots.","</b>"))
      }else{
        return()
      }
    }
    
  })
  
  # 
  output$year_1 <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        selectizeInput("dyn_year_1","Select Year", choices = c(2016:2019), width = "100px")
      }
    }
  })
  
  
  
  
  Plot_Data <- reactive({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        s1 <- Sys.time()
        
        df <- readxl::read_xls(input$file1$datapath)
        trend_data <- as.data.frame(df[, c("Category", "Order Date", "Sales")])
        bar_data <- as.data.frame(df %>% group_by(Region) %>% summarise(Sales = sum(Sales)))
        map_data <- as.data.frame(df %>% group_by(State) %>% summarise(Sales = sum(Sales)))
        
        s2 <- Sys.time()
        print(paste("Plot_Data: ", (s2-s1)))
      }
      return(list(trend_data, bar_data, map_data))
    }
  })
  
  
  
  
  output$trend_plot <- renderUI({
    if(is.null(input$file1)){
      # print("161")
      return()
    }else if(!is.null(input$file1) & str_sub(input$file1$name, -3) == "xls"){
      plotlyOutput("dyn_trend_plot")  %>% withSpinner(color="#0dc5c1")
    }else if(!is.null(input$file1) & str_sub(input$file1$name, -3) != "xls"){
      return()
    }
  })
  output$dyn_trend_plot <- renderPlotly({
    
    # data <- readxl::read_xls(input$file1$datapath)
    # data$
    
    
    # "Row ID"         "Order ID"       "Order Date"     "Ship Date"      "Ship Mode"      "Customer ID"    "Customer Name"  "Segment"       
    # "Country/Region" "City"           "State"          "Postal Code"    "Region"         "Product ID"     "Category"       "Sub-Category"  
    # "Product Name"   "Sales"          "Quantity"       "Discount"       "Profit" 
    # print("176")
    s1 <- Sys.time()
    df_cat_date_sales <- as.data.frame(Plot_Data()[[1]])
    # df_cat_date_sales <- readxl::read_xls(input$file1$datapath)[, c("Category", "Order Date", "Sales")]
    # df_cat_date_sales <- df[, c("Category", "Order Date", "Sales")]
    df_cat_date_sales$year <- year(as.Date(df_cat_date_sales$`Order Date`))
    df_cat_date_sales$mon <- month(as.Date(df_cat_date_sales$`Order Date`))
    df_cat_date_sales$month <- month.name[month(as.Date(df_cat_date_sales$`Order Date`))]
    
    df_cat_date_sales_year <- df_cat_date_sales[df_cat_date_sales$year == input$dyn_year_1,]
    
    pivot_data <- as.data.frame(df_cat_date_sales_year %>% group_by(Category, mon, month) %>% summarise(Mean_Sales= mean(Sales)))
    pivot_data_fur <- pivot_data %>% filter(Category == "Furniture")
    pivot_data_off <- pivot_data %>% filter(Category == "Office Supplies")
    pivot_data_tec <- pivot_data %>% filter(Category == "Technology")
    
    # "Furniture"       "Office Supplies" "Technology"
    my_plot <- plot_ly() %>%
      add_trace(x=~pivot_data_fur$mon, y=~pivot_data_fur$Mean_Sales, type="scatter", mode="lines+markers", name="Furniture")%>%
      add_trace(x=~pivot_data_off$mon, y=~pivot_data_off$Mean_Sales , name="Office Supplies", type="scatter", mode="lines+markers")%>%
      add_trace(x=~pivot_data_tec$mon, y=~pivot_data_tec$Mean_Sales , name="Technology", type="scatter", mode="lines+markers")%>%
      layout(
        # xaxis=list(title="Month"),
        xaxis = list(
          title="Months",hoverformat='f',zeroline=FALSE,
          ticktext = list("Jan", "Feb", "Mar", "Ap", "May", "Jun", "Jul", "Aug",  "Sep", "Oct", "Nov", "Dec"), 
          tickvals = list(1,2,3,4,5,6,7,8,9,10,11,12),
          tickmode = "array"
        ),
        yaxis=list(title="Sales",hoverformat='f',zeroline=FALSE)
      )
    my_plot$elementId <- NULL        # This is to remove the warning Warning in origRenderFunc() :
    s2 <- Sys.time()
    print(paste("trend_plot: ", (s2-s1)))
    
    
    output$trend_data_download <- renderUI({
      if(!is.null(input$file1)){
        if(str_sub(input$file1$name, -3) == "xls"){
          downloadButton("dyn_trend_data_download", "Download data")
        }
      }
    })
    
    output$dyn_trend_data_download <- downloadHandler(
      filename = function() {
        paste("line_plot_data_", input$dyn_year_1, ".csv", sep = "")
      },
      content = function(file) {
        write.csv(pivot_data, file, row.names = FALSE)
      }
    )
    
    my_plot
    
  })
  output$trend_plot_text <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        paste0("This plot shows the average sales trend of the three categories for the selected year.")
      }else{
        return()
      }
    }
  })
  output$trend_plot_head <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        htmlOutput(("dyn_trend_plot_head"))
      }else{
        return()
      }
    }
  })
  output$dyn_trend_plot_head <- renderUI({
    HTML(paste("<b>","Sales Trend","</b>"))
  })
  
  
  output$reg_sale_barplot <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        plotlyOutput("dyn_bar_plot")  %>% withSpinner(color="#0dc5c1")
      }else{
        return()
      }
    }
  })
  output$dyn_bar_plot <- renderPlotly({
    s1 <- Sys.time()
    region_wise_sales <- as.data.frame(Plot_Data()[[2]])
    # region_wise_sales <- as.data.frame(readxl::read_xls(input$file1$datapath) %>% group_by(Region) %>% summarise(Sales = sum(Sales)))
    # region_wise_sales <- as.data.frame(df %>% group_by(Region) %>% summarise(Sales = sum(Sales)))
    region_wise_sales$Sales <- round(region_wise_sales$Sales)
    fig <- plot_ly(
      x = region_wise_sales$Region,
      y = region_wise_sales$Sales,
      name = "SF Zoo",
      type = "bar"
    )
    s2 <- Sys.time()
    print(paste("bar_plot: ", (s2-s1)))
    
    output$bar_data_download <- renderUI({
      if(!is.null(input$file1)){
        if(str_sub(input$file1$name, -3) == "xls"){
          downloadButton("dyn_bar_data_download", "Download data")
        }
      }
    })
    
    output$dyn_bar_data_download <- downloadHandler(
      filename = function() {
        paste("barplot_data", ".csv", sep = "")
      },
      content = function(file) {
        write.csv(region_wise_sales, file, row.names = FALSE)
      }
    )
    
    
    fig
  })
  output$reg_sale_barplot_text <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        paste0("This plot shows the sales distribution across the four regions of United States of America from 2016-2019.")
      }else{
        return()
      }
    }
  })
  
  output$reg_sale_barplot_head <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        htmlOutput(("dyn_reg_sale_barplot_head"))
      }else{
        return()
      }
    }
  })
  output$dyn_reg_sale_barplot_head <- renderUI({
    HTML(paste("<b>","Region-Wise Sales Distribution","</b>"))
  })
  
  
  
  
  output$state_wise_sales_map <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        leafletOutput("dyn_map")  %>% withSpinner(color="#0dc5c1")
      }else{
        return()
      }
    }
  })
  output$dyn_map <- renderLeaflet({
    s1 <- Sys.time()
    pivot_state_sales <- as.data.frame(Plot_Data()[[3]])
    # pivot_state_sales <- as.data.frame(readxl::read_xls(input$file1$datapath) %>% group_by(State) %>% summarise(Sales = sum(Sales))) # Our sequential State alignment
    a <- sort(unique(pivot_state_sales$State))
    b <- shape1$NAME
    c <- b[b %in% a]
    required_states <- shape1[shape1$NAME %in% a, ]
    # c <- data.frame(a,b)
    
    shape1Data <- spTransform(required_states, CRS("+proj=longlat +ellps=GRS80"))
    df1 <- data.frame(State = shape1Data$NAME)                                           # Shapefile non-sequential State alignment
    
    for (i in 1:nrow(pivot_state_sales)) {
      df1$Sales[i] <- pivot_state_sales[df1$State[i] == pivot_state_sales$State, 2]      # Proper State alignment
    }
    
    shape1Data$Sales <- round(df1$Sales)
    
    # Using Arithmetic Progression to determine the bins for the color palette
    # YlOrRd color palette accepts 9 bins max
    first <- min(shape1Data$Sales)
    l <- max(shape1Data$Sales)
    d <- (l-first)/8
    i <- c(1:8)
    series <- c(first, first + i*d)
    bins <- series
    pal <- colorBin("YlOrRd", domain = shape1Data$Sales, bins = bins)
    
    map1 <- leaflet(shape1Data) %>% addTiles() %>%
      addPolygons(fillColor = ~pal(Sales), weight = 2, smoothFactor = 0.5,
                  opacity = 0.5, fillOpacity = 1, color = "white",
                  highlightOptions = highlightOptions(color = "black", weight = 2,
                                                      bringToFront = TRUE),
                  label = paste0(shape1Data$NAME,": ",round(shape1Data$Sales))
      ) %>%
      addLegend("bottomright", pal = pal, values = ~Sales,
                title = "Avg. Sales (2016-2019)",
                labFormat = labelFormat(prefix = "$"),
                opacity = 1
      )
    s2 <- Sys.time()
    print(paste("map_plot: ", (s2-s1)))
    
    output$map_data_download <- renderUI({
      if(!is.null(input$file1)){
        if(str_sub(input$file1$name, -3) == "xls"){
          downloadButton("dyn_map_data_download", "Download data")
        }
      }
    })
    
    output$dyn_map_data_download <- downloadHandler(
      filename = function() {
        paste("map_data", ".csv", sep = "")
      },
      content = function(file) {
        write.csv(pivot_state_sales, file, row.names = FALSE)
      }
    )
    
    map1
  })
  output$state_wise_sales_map_text <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        paste0("     This map shows the sales distribution across the states of United States of America from 2016-2019.")
      }else{
        return()
      }
    }
  })
  # state_wise_sales_map_head
  output$state_wise_sales_map_head <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        htmlOutput(("dyn_state_wise_sales_map_head"))
      }else{
        return()
      }
    }
  })
  output$dyn_state_wise_sales_map_head <- renderUI({
    HTML(paste("<b>","State-Wise Sales Distribution","</b>"))
  })
  
  
  output$cluster_head <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        htmlOutput(("dyn_cluster_head"))
      }else{
        return()
      }
    }
  })
  output$dyn_cluster_head <- renderUI({
    HTML(paste("<b>","Cluster Analysis Summary","</b>"))
  })
  
  # selectizeInput("kval", "Select No. of Clusters", c(1:50))
  
  output$kval <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        selectizeInput("dyn_kval", "No. of Clusters", c(2:20), selected = c(3))
      }else{
        return()
      }
    }
  })
  
  output$niter <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        selectizeInput("dyn_niter", "No. of Iterations", c(1:25), selected = (25))
      }else{
        return()
      }
    }
  })
  
  
  
  
  # ClusterSummary_tab
  output$ClusterSummary_tab <- renderUI({
    if(is.null(input$file1)){
      return()
    }else if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        DT::dataTableOutput("dyn_ClusterSummary_tab") %>% withSpinner(color="#0dc5c1")
      }else{
        return()
      }
    }
  })
  
  output$dyn_ClusterSummary_tab <- DT::renderDataTable({
    # input$submit_1
    if (!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        # df <- readxl::read_xls("C:/Users/91877/Desktop/My_Projects/SuperstoreAPP_Demo/SuperstoreApp_Demo_v2/Sample - Superstore.xls")[, c("Order Date", "Customer ID", "Order ID", "Quantity", "Sales", "Profit")]
        df <- readxl::read_xls(input$file1$datapath)[, c("Order Date", "Customer ID", "Order ID", "Quantity", "Sales", "Profit")]
        df$year <- year(df$`Order Date`)
        df1 <- df[df$year %in% input$dyn_year, ]
        df2 <- as.data.frame(df1 %>% group_by(`Customer ID`) %>% summarise(Total_Quantity = sum(Quantity),
                                                                           Total_Sales = sum(Sales),
                                                                           Total_Profit = sum(Profit)))
        
        df2$Quantity_scaled <- (df2$Total_Sales - mean(df2$Total_Quantity))/sd(df2$Total_Quantity)
        df2$Sales_scaled <- (df2$Total_Sales - mean(df2$Total_Sales))/sd(df2$Total_Sales)
        df2$Profit_scaled <- (df2$Total_Profit - mean(df2$Total_Profit))/sd(df2$Total_Profit)
        
        k_val <- input$dyn_kval
        iter <- input$dyn_niter
        
        b <- c(1:4)
        a <- c()
        
        if(!is.null(input$dyn_dep)){
          if(length(input$dyn_dep) == 1){
            if(input$dyn_dep == "Quantity"){
              a <- c(5)
            }else if(input$dyn_dep == "Sales"){
              a <- c(6)
            }else if(input$dyn_dep == "Profit"){
              a <- c(7)
            }
          }else if(length(input$dyn_dep) == 2){
            if(input$dyn_dep[1] == "Quantity" & input$dyn_dep[2] == "Sales" | input$dyn_dep[1] == "Sales" & input$dyn_dep[2] == "Quantity" ){
              a <- c(5,6)
            }else if(input$dyn_dep[1] == "Quantity" & input$dyn_dep[2] == "Profit" | input$dyn_dep[1] == "Profit" & input$dyn_dep[2] == "Quantity" ){
              a <- c(5,7)
            }else if(input$dyn_dep[1] == "Profit" & input$dyn_dep[2] == "Sales" | input$dyn_dep[1] == "Sales" & input$dyn_dep[2] == "Profit" ){
              a <- c(6,7)
            }
          }else{
            a <- c(5:7)
          }
        }
        
        if(!is.null(a)){
          z <- c(b, a)
          set.seed(input$dyn_seed)
          clusters <- kmeans(df2[,a], centers = input$dyn_kval, iter.max = input$dyn_niter)
          # 41, 4, 5, 186, 44, 493
          df2$ClusterGroup <- clusters$cluster
          df3 <- as.data.frame(df2 %>% group_by(ClusterGroup) %>% summarise(CustomerCount = length(`Customer ID`),
                                                                            TotalQuantity = sum(Total_Quantity),
                                                                            TotalSales = round(sum(Total_Sales)),
                                                                            TotalProfit = round(sum(Total_Profit))))
          
          df3$CustomerCount <- format(df3$CustomerCount,big.mark=",",trim = FALSE)
          df3$TotalQuantity <- format(df3$TotalQuantity,big.mark=",",trim = FALSE)
          df3$TotalSales <- format(df3$TotalSales,big.mark=",",trim = FALSE)
          df3$TotalProfit <- format(df3$TotalProfit,big.mark=",",trim = FALSE)
          colnames(df3) <- c("Cluster Group", "No. of Customers", "Total Quantity", "Total Sales", "Total Profit")
          df3 <- df3[order(df3$`Total Profit`), ]
          
          datatable(df3, 
                    options = list(
                      dom = 't',
                      scroller = TRUE,
                      scrollX = TRUE, 
                      "pageLength" = k_val),
                    rownames = FALSE
          )
        }else{
          df3 <- data.frame(matrix(c(NA,NA,NA,NA,NA), nrow = 1, ncol = 5))[-1,]
          # df3 <- data.frame(matrix(c("-", "-", "-", "-"), nrow = 1, ncol = 5))
          colnames(df3) <- c("Cluster Group", "No. of Customers", "Total Quantity", "Total Sales", "Total Profit")
          datatable(df3, 
                    options = list(
                      dom = 't',
                      scroller = TRUE,
                      scrollX = TRUE, 
                      "pageLength" = 6),
                    rownames = FALSE
          )
        }
      }
    }
  })
  
  
  output$dep <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        numeric_count <- c("Quantity", "Sales", "Profit")
        checkboxGroupInput("dyn_dep", "Cluster Variables", choices = numeric_count)
      }
    }
  })
  
  output$year <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        # numeric_count <- c("Quantity", "Sales", "Profit")
        selectizeInput("dyn_year", "Year", c(2018:2019), selected = c(2018))
        # checkboxGroupInput("dyn_dep", "Select Cluster Variables", choices = numeric_count)
      }
    }
  })
  
  output$seed <- renderUI({
    if(!is.null(input$file1)){
      if(str_sub(input$file1$name, -3) == "xls"){
        selectizeInput("dyn_seed", "Seed", c(1:1000), selected = c(123))
      }else{
        return()
      }
    }
  })
  
  
  
}



shinyApp(ui, server)